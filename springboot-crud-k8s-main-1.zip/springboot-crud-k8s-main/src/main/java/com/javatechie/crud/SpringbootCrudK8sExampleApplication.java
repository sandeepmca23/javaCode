package com.javatechie.crud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootCrudK8sExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootCrudK8sExampleApplication.class, args);
	}

}
